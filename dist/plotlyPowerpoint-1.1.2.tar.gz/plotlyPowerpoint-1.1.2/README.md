# Plotly & Powerpoint

A library used to create powerpoint slides including plotly charts. Use this to automate powerpoint creation including certiain charts/visualizations.